import hashlib

def rotl(x, n):
    return ((x << n) | (x >> (32 - n))) & 0xFFFFFFFF

def round_keys(key):
    h = hashlib.sha256(key).digest()
    return [int.from_bytes(h[i:i+4], "big") for i in range(0, 32, 4)]

def f(x, k):
    return rotl(x, 5) ^ rotl(x, 13) ^ (x >> 3) ^ k

def encrypt_block(block, rks):
    L = int.from_bytes(block[:4], "big")
    R = int.from_bytes(block[4:], "big")
    for k in rks:
        L, R = R, L ^ f(R, k)
    return L.to_bytes(4, "big") + R.to_bytes(4, "big")

def encrypt(data, key):
    assert len(data) % 8 == 0
    rks = round_keys(key)
    return b"".join(encrypt_block(data[i:i+8], rks) for i in range(0, len(data), 8))