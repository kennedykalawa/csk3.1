# Vault key ceremony (reference build).
import hashlib
from Crypto.Util.number import getPrime, isPrime, bytes_to_long
import secrets

E = 65537

def derive_prefix(d):
    """400-bit key-ceremony prefix derived from the signing key."""
    raw = hashlib.shake_256(d.to_bytes(32, "big") + b"vault-kdf-v1").digest(50)
    return int.from_bytes(raw, "big") | (1 << 399)

def make_modulus(d):
    pre = derive_prefix(d)
    while True:
        p = (pre << 112) | secrets.randbits(112) | 1
        if isPrime(p):
            break
    q = getPrime(512)
    return p, q

def seal(d, secret_bytes):
    p, q = make_modulus(d)
    n = p * q
    c = pow(bytes_to_long(secret_bytes), E, n)
    return n, c