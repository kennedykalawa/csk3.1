FOUR DOORS - recovered from the vault infrastructure

signer.py     source of the signing service (secrets removed)
log.txt       signature log produced by that service
vault.py      source of the key ceremony
sealed.txt    output of the key ceremony
treadmill.py  source of the archive cipher
treadmill.bin the archive

treadmill.bin layout:
  bytes 0..7   nonce
  bytes 8..    AES-256-CTR ciphertext, key = the 32-byte secret sealed in
               sealed.txt (big-endian, zero-padded to 32 bytes)

Decrypted archive layout (all integers big-endian):
  u32 N
  N x (u32 plaintext block, u32 ciphertext block)   under the archive cipher
  u32 L
  L bytes: the flag, encrypted with the same cipher, 4-byte blocks,
           PKCS#7 padded to 4 bytes

The flag format is genius{...}.