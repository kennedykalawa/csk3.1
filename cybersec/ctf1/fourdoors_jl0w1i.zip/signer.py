# Vault signing service (reference build). Secrets are loaded at runtime and not included.
import hashlib

# secp256k1
P = 2**256 - 2**32 - 977
N = 0xFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFEBAAEDCE6AF48A03BBFD25E8CD0364141
G = (0x79BE667EF9DCBBAC55A06295CE870B07029BFCDB2DCE28D959F2815B16F81798,
     0x483ADA7726A3C4655DA4FBFC0E1108A8FD17B448A68554199C47D08FFB10D4B8)

def add(p1, p2):
    if p1 is None: return p2
    if p2 is None: return p1
    (x1, y1), (x2, y2) = p1, p2
    if x1 == x2 and (y1 + y2) % P == 0: return None
    if p1 == p2: l = 3 * x1 * x1 * pow(2 * y1, -1, P) % P
    else:        l = (y2 - y1) * pow(x2 - x1, -1, P) % P
    x3 = (l * l - x1 - x2) % P
    return (x3, (l * (x1 - x3) - y1) % P)

def mul(k, pt=G):
    r = None
    while k:
        if k & 1: r = add(r, pt)
        pt = add(pt, pt); k >>= 1
    return r

M = 0xFFFFFFFFFFFFFFC5          # 2**64 - 59, prime

class Rng:
    def __init__(self, a, c, seed):
        self.a, self.c, self.x = a, c, seed
    def next(self):
        self.x = (self.a * self.x + self.c) % M
        return self.x

def sign_all(d, msgs, a, c, seed):
    rng = Rng(a, c, seed)
    out = []
    for m in msgs:
        h = int.from_bytes(hashlib.sha256(m.encode()).digest(), "big")
        session = rng.next()                          # shown in the log as the request id
        k = (rng.next() << 128) | (rng.next() << 64) | rng.next()   # 192-bit nonce
        r = mul(k)[0] % N
        s = pow(k, -1, N) * (h + r * d) % N
        out.append((m, r, s, session))
    return out