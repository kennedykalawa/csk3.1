# "Treadmill" block cipher: 32-bit block, 16-bit halves, 48-bit key, 32 rounds.
M = 0xFFFF
ROUNDS = 32

def rotl(x, n):
    return ((x << n) | (x >> (16 - n))) & M

def F(x, k):
    k0, k1, k2 = k
    a = (x + k0) & M
    a ^= k1
    a = rotl(a, 5)
    return (a + k2) & M

def enc_block(blk, k):
    L, R = blk >> 16, blk & M
    for _ in range(ROUNDS):
        L, R = R, L ^ F(R, k)
    return (L << 16) | R

def dec_block(blk, k):
    L, R = blk >> 16, blk & M
    for _ in range(ROUNDS):
        L, R = R ^ F(L, k), L
    return (L << 16) | R